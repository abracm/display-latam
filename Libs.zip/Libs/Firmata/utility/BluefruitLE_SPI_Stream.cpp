/*
 * Implementation is in BluefruitLE_SPI_Stream.h to avoid making
 * Adafruit_BluefruitLE_nRF51 a build-time dependency for all projects that use
 * the Firmata library.
 */
